# Senior Computational Experimental Design Engineer

**Role Title:** Senior Computational Experimental Design Engineer  
**Division / Function:** Fusion Technology Division  
**Grade:** G  
**Reports to:** Lead Computational Experimental Design Engineer (or higher)  
**Skill Type:** Engineering  
**Line Manager:** May be applicable  

## Overall Purpose

Define and lead significant technical work packages for the design, simulation and analysis of materials and component validation experiments in extreme fusion environments. Own major computational methods, libraries or technical areas spanning computational experimental design, sensor and measurement modelling, VVUQ and performance-aware computational engineering.

The role provides technical direction, assurance and mentoring to deliver complex multidisciplinary outcomes that improve validation evidence and the effective use of experimental resources. This supports risk-aware engineering, sustainable and commercially viable fusion technologies and wider UK economic benefit.

A Senior Computational Experimental Design Engineer defines and leads significant technical work packages, owns major computational methods or libraries, and provides technical leadership and mentoring to deliver complex multidisciplinary outcomes.

## Accountabilities

- Define significant technical work packages from broader project objectives, establishing scope, methods, delivery plans, dependencies, acceptance evidence and resource requirements.
- Exercise substantial independence and professional judgement in selecting, adapting and approving mathematical and computational methods within assigned areas, leading development of new approaches where established methods are insufficient or precedent is limited.
- Own the architecture, development and technical quality of major libraries, subsystems or specialist capability areas.
- Set performance, verification, interoperability, documentation and maintainability requirements for assigned software and methods.
- Define validation and uncertainty strategies for significant projects and review the adequacy of sensor models, validation metrics and experimental-design approaches.
- Coordinate multidisciplinary contributors across simulation, experiments, measurement science, applied mathematics and computing.
- Assign and review technical work, resolve methodological and implementation issues, and provide authoritative recommendations within delegated areas.
- Manage technical risks, schedules, resources and interfaces within assigned work packages.
- Lead research studies, publications, conference outputs and technical work packages within proposals or collaborative bids.
- Represent the organisation in specialist technical forums and build relationships with universities, industry and research partners.
- Mentor and develop less experienced engineers and researchers, contributing to recruitment, performance development and capability planning.
- Translate computational methods and tools into use across fusion programmes and adjacent high-value engineering sectors.

## Specific Qualifications / Experience

### Qualifications

- A degree, or equivalent demonstrable experience, in a relevant quantitative discipline.
- Extensive relevant experience or a doctorate with demonstrable postdoctoral, industrial or technical leadership experience.

### Computational & Programming Knowledge & Experience

- Advanced knowledge of Python scientific computing and compiled-language interoperability.
- Strong knowledge of one or more systems programming languages and performance-aware computational engineering.
- Demonstrable experience defining architecture and development practices for major libraries, subsystems or technical areas.
- Ability to review and approve evidence concerning correctness, robustness, performance and maintainability.

### Engineering & Mathematical Knowledge & Experience

- Advanced knowledge in at least one core capability area and strong working knowledge across the others.
- Ability to analyse complex and variable engineering problems, evaluate alternative approaches and lead development of methods where established solutions are inadequate.
- Experience defining verification, validation and uncertainty approaches for significant technical work.

### Specialist Knowledge & Experience

- Recognised internal specialist knowledge in computational experimental design, sensor and measurement modelling, VVUQ or performance-aware computational engineering.
- Experience integrating multiple specialist areas into a coherent library, subsystem or work package.

### Research Knowledge & Experience

- A strong track record of leading research studies, publications and conference outputs.
- Experience developing proposals, leading technical work packages and collaborating with external partners.
- Ability to communicate complex technical issues, influence across disciplines and build consensus.
- Experience mentoring less experienced colleagues and coordinating their technical delivery.

## Additional Duties

- May be appointed as a line manager for up to eight direct reports, with responsibility focused on pastoral care, performance development and non-technical people management.
- Expected to provide technical leadership, task coordination, mentoring and review, and may direct technical activity equivalent to approximately 2–3 FTE.
- May manage work-package budgets of up to approximately £250k per year within delegated controls, including computing resources or experimental activity.
- Represent the organisation at national and international technical meetings, conferences and collaborations.
- Undertake national or international travel where required.
