# Head of Experimental Design

**Role Title:** Head of Experimental Design  
**Division / Function:** Fusion Technology Division  
**Grade:** J  
**Reports to:** Divisional Director, Programme Director or equivalent  
**Skill Type:** Engineering  
**Line Manager:** May be applicable  

## Overall Purpose

A Head of Experimental Design independently leads a major integrated programme or capability portfolio, sets strategic technical direction and is accountable for substantial organisational, scientific and engineering outcomes.

The purpose of this role is to create and direct a major organisational capability in experimental design, integrating computational engineering, advanced diagnostics and physical experimentation to establish new research directions and transform fusion validation. The role leads a substantial portfolio of programmes, capabilities and senior technical contributors. It sets cross-cutting direction across computational experimental design, practical experimentation, sensor and measurement modelling, engineering validation and uncertainty quantification, performance-aware scientific computing and the translation of evidence into engineering decisions. It shapes organisational priorities, builds external partnerships and ensures investment is directed toward the capabilities needed for future fusion delivery.

By establishing new areas of research and turning them into sustained engineering capability, the role strengthens United Kingdom Atomic Energy Authority (UKAEA)'s scientific leadership, accelerates innovation into the fusion industry and adjacent high-value engineering sectors, and creates significant United Kingdom (United Kingdom) economic impact. Through this portfolio leadership, the role helps lead the delivery of sustainable fusion energy and maximise the scientific and United Kingdom economic benefit of UKAEA's research, software, facilities, partnerships and people.

## Accountabilities

- Define and lead a major multiyear portfolio of integrated computational and experimental research, engineering and capability development.
- Establish new research directions and convert them into sustained organisational programmes, methods, facilities, software and partnerships.
- Set strategic technical direction across experimental design, measurement science, engineering validation and uncertainty quantification, advanced diagnostics and performance-aware computing.
- Direct multiple substantial programmes or capability areas and coordinate Principal-level technical leaders and senior collaborators.
- Hold senior delegated authority for major technical approaches, validation strategies, evidence standards and programme decisions.
- Lead allocation and prioritisation of substantial people, budgets, facilities, computing resources and experimental activity across the portfolio.
- Scrutinise, challenge and improve major organisational engineering and scientific programmes where experimental evidence is critical.
- Originate and lead nationally or internationally competitive funding proposals, strategic partnerships and external collaborations.
- Shape divisional and organisational strategy, investment and capability planning in the discipline.
- Represent the organisation as a senior authority with government, industry, academia, funders and international partners.
- Translate integrated computational and experimental methods into adoption across fusion and adjacent high-value engineering sectors.
- Build a sustainable leadership pipeline, professional community, succession plan and long-term organisational capability.

## Specific Qualifications / Experience

### Qualifications

- A degree, or equivalent demonstrable experience, in a relevant engineering, physical science, mathematical or computational discipline.
- Deep, broad and comprehensive experience across computational research, engineering experimentation and major programme leadership.
- A doctorate or equivalent record of original scientific and engineering achievement would normally be expected.
- Chartered status, Fellowship of an appropriate professional body or equivalent standing may be advantageous.

### Computational Knowledge and Experience

- Authoritative knowledge of advanced scientific computing, numerical methods, high-performance software and computational architecture.
- Proven ability to direct coherent technical strategy across multiple toolboxes, software platforms, projects and teams.
- Strong understanding of performance-aware computing across modern central processing unit (CPU), vector, distributed and accelerator systems.
- Experience establishing organisational standards for software assurance, verification, maintainability, interoperability and translation into use.
- Track record of creating or sponsoring computational capabilities that materially change scientific, engineering or industrial outcomes.

### Experimental Knowledge and Experience

- Authoritative practical knowledge of experimental engineering, measurement systems, advanced diagnostics and validation.
- Proven ability to direct major integrated experimental programmes spanning facilities, instrumentation, software, modelling and multidisciplinary teams.
- Deep understanding of measurement assurance, calibration, traceability, uncertainty and evidence quality.
- Experience making or approving strategic decisions on experimental capability, facility use, instrumentation investment and diagnostic development.
- Broad knowledge across multiple experimental and diagnostic domains, supported by deep expertise in at least one.

### Engineering Analysis and Validation Knowledge and Experience

- Recognised authority in experimental design, measurement modelling, engineering validation and uncertainty quantification or a closely related discipline.
- Proven ability to define integrated strategies for problems with high ambiguity, limited precedent and substantial organisational consequences.
- Extensive experience linking engineering decisions to evidence requirements, uncertainty, risk, information value and programme cost.
- Ability to assess and challenge major technical programmes and determine whether the available evidence is sufficient.
- Strong judgement across computational, experimental, organisational and strategic trade-offs, including policy or standards development.

### Research, Communication and Leadership Experience

- Sustained track record of independently leading major externally funded or organisational programmes and substantial multidisciplinary resources.
- Mandatory experience providing technical or matrix leadership across multiple senior contributors, teams or institutions.
- Evidence of establishing new research directions, capabilities or communities of practice.
- Strong national and international reputation with established networks across academia, industry, government and funders.
- Ability to influence senior leadership, shape organisational strategy and develop Principal-level staff and future leaders.

## Additional Duties

- May hold line-management and/or matrix-management responsibility for a substantial team, portfolio or network.
- May hold authority over major budgets, facilities, resources and organisational technical approvals.
- Represent the organisation on major national and international advisory bodies, expert panels and strategic collaborations.
- Undertake national and international travel as required.
